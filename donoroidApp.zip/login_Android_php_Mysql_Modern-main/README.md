# Sign in And Sign up PHP Android
 Dashboard Wallet in Android Studio, Login and Register UI/UX Design Android Studio XML || Animation Transition || Sign in / Sign up UI The best UI design using Android, Login PHP and MySQL Android, Fragment, Clipboard, Grid and Splash. 

<p align="center">
  <img src="https://github.com/ASAZING/login_Android_php_Mysql_Modern/blob/main/screenshots/Login.png" width="200" title="Login" >
  <img src="https://github.com/ASAZING/login_Android_php_Mysql_Modern/blob/main/screenshots/Register.png" width="200" alt="Register">
  <img src="https://github.com/ASAZING/login_Android_php_Mysql_Modern/blob/main/screenshots/Wallet.png" width="200" alt="Wallet">
  <img src="https://github.com/ASAZING/login_Android_php_Mysql_Modern/blob/main/screenshots/Copy.png" width="200" alt="Copy">
  <img src="https://github.com/ASAZING/login_Android_php_Mysql_Modern/blob/main/screenshots/Grid.png" width="200" alt="Grid">
</p>

# Source
<ul>
    <li>Android UI Desing
        <ul>
          <li>
          <a href="https://codinginsight.live/t_login_register_1.html?i=1">Pratik D</a>
          </li>
        </ul>
    </li>
    <li>Wallet
        <ul>
           <li>
            <a href="https://www.youtube.com/watch?v=RIsvbkSrjLE&ab_channel=j2jtutorial">j2j tutorial</a>
           </li>
        </ul>
    </li>
</ul>
