package com.asazing.loginui.ui.dashboard;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;

import androidx.lifecycle.ViewModel;

import static androidx.core.content.ContextCompat.getSystemService;


public class DashboardViewModel extends ViewModel{


    public DashboardViewModel() {


    }


}