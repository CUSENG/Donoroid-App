package com.asazing.loginui.ui.home;

import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    public HomeViewModel() {

    }

}