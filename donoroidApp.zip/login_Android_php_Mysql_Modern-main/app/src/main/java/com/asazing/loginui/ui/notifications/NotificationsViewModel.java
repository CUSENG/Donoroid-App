package com.asazing.loginui.ui.notifications;

import androidx.lifecycle.ViewModel;

public class NotificationsViewModel extends ViewModel {

    public NotificationsViewModel() {

    }


}